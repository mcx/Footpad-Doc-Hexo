<!-- use this template only to report a bug or ask a question -->
<!-- fill this part for bugs reporting or questions -->
### Configuration

 - **Operating system with version** : 
 - **Node version** : 
 - **Hexo version** : 
 - **Hexo-cli version** : 
 - **Tranquilpeak version** : <!-- Does the theme is original or modified? -->
 
<!-- fill this part for bugs reporting if needed  -->
### Actual behavior

<!-- fill this part for bugs reporting if needed  -->
### Expected behavior

<!-- fill this part for bugs reporting if needed -->
### Steps to reproduce the behavior
